package com.intechdev.IpasKala.interfaceapp;

/**
 * Created by HBM on 21/07/2018.
 */

public interface ItemClicked {
    public void onItemClicked(int action, final String id, final String data, final Object object);
}
