package com.intechdev.IpasKala.interfaceapp;

/**
 * Created by HBM on 27/04/2018.
 */

public interface DisconnectInternet {

     void disconnectInternet(int networkType, String strMsg);
}
